package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.MatDAO;
import Model.MatDTO;
import Model.RegionDAO;
import Model.RegionDTO;

@WebServlet("/Keyword")
public class Keyword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String kw = request.getParameter("search");
		
		MatDAO dao = new MatDAO();
		ArrayList<MatDTO> list = new ArrayList<MatDTO>();
		list = dao.kwSearch(kw);
	
        request.setAttribute("list", list);
		ServletContext context =getServletContext();
        RequestDispatcher dispatcher = context.getRequestDispatcher("/local1.jsp"); //�ѱ� ������ �ּ�
        dispatcher.forward(request, response);
	}

}
