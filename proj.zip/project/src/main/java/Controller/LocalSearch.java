package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.ha.backend.Sender;

import com.google.gson.JsonParser;

import Model.ClientDAO;
import Model.ClientDTO;
import Model.MatDAO;
import Model.MatDTO;
import Model.RegionDAO;
import Model.RegionDTO;

@WebServlet("/LocalSearch")
public class LocalSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("UTF-8");
		String big_city = request.getParameter("addressRegion");
		String small_city = request.getParameter("addressDo");
		
		
		RegionDTO dto = new RegionDTO(big_city,small_city);
		RegionDAO dao = new RegionDAO();
		dto = dao.findRegionID(big_city, small_city);
		int reg_id = dto.getReg_id();
		
		
		MatDAO dao2 = new MatDAO();
		ArrayList<MatDTO> list = new ArrayList<MatDTO>();
		list = dao2.findLocal(reg_id);
	
        request.setAttribute("list", list);
		ServletContext context =getServletContext();
        RequestDispatcher dispatcher = context.getRequestDispatcher("/local1.jsp"); //�ѱ� ������ �ּ�
        dispatcher.forward(request, response);
		
	}

}
