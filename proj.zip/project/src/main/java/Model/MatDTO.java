package Model;

public class MatDTO {

	private String mat_id;
	private String mat_name;
	private String mat_phone;
	private String mat_addr;
	private int reg_id;
	private String mat_pro_name;
	private String mat_menu;
	private String mat_pro_count;
	private String mat_picture;
	
	
	
	public MatDTO(String mat_id, String mat_name, String mat_phone, String mat_addr, int reg_id, String mat_pro_name,
			String mat_menu, String mat_pro_count, String mat_picture) {
		super();
		this.mat_id = mat_id;
		this.mat_name = mat_name;
		this.mat_phone = mat_phone;
		this.mat_addr = mat_addr;
		this.reg_id = reg_id;
		this.mat_pro_name = mat_pro_name;
		this.mat_menu = mat_menu;
		this.mat_pro_count = mat_pro_count;
		this.mat_picture = mat_picture;
	}

	public MatDTO(String mat_id, String mat_name, String mat_phone, String mat_addr, String mat_pro_name,
			String mat_menu, String mat_pro_count, String mat_picture) {
		super();
		this.mat_id = mat_id;
		this.mat_name = mat_name;
		this.mat_phone = mat_phone;
		this.mat_addr = mat_addr;
		this.mat_pro_name = mat_pro_name;
		this.mat_menu = mat_menu;
		this.mat_pro_count = mat_pro_count;
		this.mat_picture = mat_picture;
	}
	
	public MatDTO(String mat_id, String mat_name, String mat_picture) {
		super();
		this.mat_id = mat_id;
		this.mat_name = mat_name;
		this.mat_picture = mat_picture;
	}

	public MatDTO() {
		super();
	}

	public String getMat_id() {
		return mat_id;
	}

	public void setMat_id(String mat_id) {
		this.mat_id = mat_id;
	}

	public String getMat_name() {
		return mat_name;
	}

	public void setMat_name(String mat_name) {
		this.mat_name = mat_name;
	}

	public String getMat_phone() {
		return mat_phone;
	}

	public void setMat_phone(String mat_phone) {
		this.mat_phone = mat_phone;
	}

	public String getMat_addr() {
		return mat_addr;
	}

	public void setMat_addr(String mat_addr) {
		this.mat_addr = mat_addr;
	}

	public int getReg_id() {
		return reg_id;
	}

	public void setReg_id(int reg_id) {
		this.reg_id = reg_id;
	}

	public String getMat_pro_name() {
		return mat_pro_name;
	}

	public void setMat_pro_name(String mat_pro_name) {
		this.mat_pro_name = mat_pro_name;
	}

	public String getMat_menu() {
		return mat_menu;
	}

	public void setMat_menu(String mat_menu) {
		this.mat_menu = mat_menu;
	}

	public String getMat_pro_count() {
		return mat_pro_count;
	}

	public void setMat_pro_count(String mat_pro_count) {
		this.mat_pro_count = mat_pro_count;
	}

	public String getMat_picture() {
		return mat_picture;
	}

	public void setMat_picture(String mat_picture) {
		this.mat_picture = mat_picture;
	}
	
	
	
	
}
