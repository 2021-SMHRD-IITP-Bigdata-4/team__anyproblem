package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MatDAO {
	
	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	ResultSet rs = null;
	MatDTO matDto = null;
	MatDTO TvP = null;
	MatDTO local = null;
	MatDTO dto = null;
	ArrayList<MatDTO> list = null;
	ArrayList<MatDTO> list3 = null;
	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String db_id = "campus_e4";
			String db_pw = "smhrd4";

			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<MatDTO> findLocal (int local_id) {
		conn();
		
		String sql = "select * from mat where reg_id = ?";
		list = new ArrayList<MatDTO>();
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1,local_id);
			rs = psmt.executeQuery();
			
			while (rs.next()) {
				String mat_id = rs.getString(1);
				String mat_name =  rs.getString(2);
				String mat_phone =  rs.getString(3);
				String mat_addr =  rs.getString(4);
				int reg_id =  rs.getInt(5);
				String mat_pro_name =  rs.getString(6);
				String mat_menu =  rs.getString(7);
				String mat_pro_count =  rs.getString(8);
				String mat_picture =  rs.getString(9);
				
				dto = new MatDTO(mat_id, mat_name, mat_phone, mat_addr, reg_id, mat_pro_name, mat_menu, mat_pro_count, mat_picture);
				list.add(dto);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
	public ArrayList<MatDTO> matTop5() {
		conn();
		ArrayList<MatDTO> list = new ArrayList<MatDTO>();
		
		String sql = "select  m.mat_name, r.mat_id, mat_picture,count(r.rev_contents) as rev_cnt from review r, mat m where r.mat_id = m.mat_id group by r.mat_id, m.mat_id, m.mat_name, m.mat_picture order by rev_cnt desc";
		try {
			psmt = conn.prepareStatement(sql);
			rs= psmt.executeQuery();
			
			while(rs.next()) {
				String mat_name = rs.getString(1);
				String mat_id = rs.getString(2);
				String mat_picture = rs.getString(3);
				
				
				matDto = new MatDTO(mat_id,mat_name,mat_picture);
				list.add(matDto);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
		
	}
	public ArrayList<MatDTO> TvP() {
		conn();
		
		ArrayList<MatDTO> list2 = new ArrayList<MatDTO>();
		try {
			String sql = "select mat_id,mat_name,mat_phone,mat_addr,mat_menu,mat_picture,mat_pro_name,mat_pro_count from mat where mat_pro_name = '����̽�ȸ' and rownum < 6 UNION select mat_id,mat_name,mat_phone,mat_addr,mat_menu,mat_picture,mat_pro_name,mat_pro_count from mat where mat_pro_name = '�������ǰ��Ĵ�' and rownum < 6 UNION select mat_id,mat_name,mat_phone,mat_addr,mat_menu,mat_picture,mat_pro_name,mat_pro_count from mat where mat_pro_name = '���ִ³༮��' and rownum < 6 order by mat_pro_name desc,mat_pro_count desc";
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				String mat_id = rs.getString(1);
				String mat_name = rs.getString(2);
				String mat_phone = rs.getString(3);
				String mat_addr = rs.getString(4);
				String mat_menu = rs.getString(5);
				String mat_picture = rs.getString(6);
				String mat_pro_name = rs.getString(7);
				String mat_pro_count = rs.getString(8);
				
				TvP = new MatDTO(mat_id, mat_name, mat_phone, mat_addr, mat_pro_name, mat_menu, mat_pro_count, mat_picture);
			
				list2.add(TvP);
			}
				
				
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list2;
		
		
	}
	
	public MatDTO allList(String matid) {
		conn();
		
		try {
			String sql = "select mat_id, mat_name, mat_phone, mat_addr, reg_id, mat_pro_name, mat_menu, mat_pro_count, mat_picture from mat where mat_id = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1,matid);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				String mat_id = rs.getString(1);
				String mat_name = rs.getString(2);
				String mat_phone = rs.getString(3);
				String mat_addr = rs.getString(4);
				int reg_id = rs.getInt(5);
				String mat_pro_name = rs.getString(6);
				String mat_menu = rs.getString(7);
				String mat_pro_count = rs.getString(8);
				String mat_picture = rs.getString(9);
				
				dto = new MatDTO(mat_id, mat_name, mat_phone, mat_addr, reg_id, mat_pro_name, mat_menu, mat_pro_count, mat_picture);
			
			
			}
				
				
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return dto;
	}
	
	
	public ArrayList<MatDTO> local() {
		conn();
		
		ArrayList<MatDTO> list3 = new ArrayList<MatDTO>();
		try {
			String sql = "select mat_id,mat_name,mat_phone,mat_addr,mat_menu,mat_picture,mat_pro_name,mat_pro_count from mat where reg_id in (select reg_id from(select * from region order by DBMS_RANDOM.value)where rownum < 20) and rownum < 16";
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				String mat_id = rs.getString(1);
				String mat_name = rs.getString(2);
				String mat_phone = rs.getString(3);
				String mat_addr = rs.getString(4);
				String mat_menu = rs.getString(5);
				String mat_picture = rs.getString(6);
				String mat_pro_name = rs.getString(7);
				String mat_pro_count = rs.getString(8);
				
				local = new MatDTO(mat_id, mat_name, mat_phone, mat_addr, mat_pro_name, mat_menu, mat_pro_count, mat_picture);
			
				list3.add(local);
			}
				
				
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list3;
		
		
	}
	
	public ArrayList<MatDTO> kwSearch(String kw) {
		conn();
		
		ArrayList<MatDTO> list3 = new ArrayList<MatDTO>();
		try {
			kw = "%"+kw+"%";
			String sql = "select * from mat where mat_menu like ? or mat_name like ? or mat_addr like ? or mat_pro_name like ? or mat_pro_count like ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1,kw);
			psmt.setString(2,kw);
			psmt.setString(3,kw);
			psmt.setString(4,kw);
			psmt.setString(5,kw);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				String mat_id = rs.getString(1);
				String mat_name = rs.getString(2);
				String mat_phone = rs.getString(3);
				String mat_addr = rs.getString(4);
				String mat_pro_name = rs.getString(6);
				String mat_menu = rs.getString(7);
				String mat_pro_count = rs.getString(8);
				String mat_picture = rs.getString(9);
				
				local = new MatDTO(mat_id, mat_name, mat_phone, mat_addr, mat_pro_name,mat_menu, mat_pro_count, mat_picture);
			
				list3.add(local);
			}
				
				
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list3;
		
		
	}
	
	
	
}
