package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Tvp2DAO {

   Connection conn = null;
   PreparedStatement psmt = null;
   int cnt = 0;
   ResultSet rs = null;
   ArrayList<TvpDTO> list2 = null;
   TvpDTO dto = null;

   public void conn() {
      try {
         Class.forName("oracle.jdbc.driver.OracleDriver");

         String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
         String db_id = "campus_e4";
         String db_pw = "smhrd4";

         conn = DriverManager.getConnection(db_url, db_id, db_pw);

      } catch (Exception e) {
         e.printStackTrace();
      }

   }
   
   public void close() {
      try {
         if (rs != null) {
            rs.close();
         }
         if (psmt != null) {
            psmt.close();
         }
         if (conn != null) {
            conn.close();
         }

      } catch (SQLException e) {
         e.printStackTrace();
      }
   }

      public ArrayList<TvpDTO> TvP() {
         conn();
         
         ArrayList<TvpDTO> list2 = new ArrayList<TvpDTO>();
         try {
            String sql = "select r.mat_id,m.mat_name,m.mat_pro_name,m.mat_pro_count, m.mat_addr,round(avg(r.rev_score),1) as rev_avg from review r, mat m "
                  + "where m.mat_id = r.mat_id "
                  + "AND m.mat_pro_name = '���ִ³༮��' "
                  + "group by r.mat_id, m.mat_name, m.mat_pro_count, m.mat_pro_name, m.mat_addr "
                  + "order by m.mat_pro_count desc";
            psmt = conn.prepareStatement(sql);
            rs = psmt.executeQuery();
            
            while(rs.next()) {   
               String mat_id =  rs.getString(1);
               String mat_name =  rs.getString(2);
               String mat_pro_name = rs.getString(3);
               String mat_pro_count =  rs.getString(4);
               String mat_addr = rs.getString(5);
               Float rev_avg = rs.getFloat(6);
               
               dto = new TvpDTO(mat_id, mat_name, mat_pro_name, mat_pro_count, mat_addr, rev_avg);
            
               list2.add(dto);
            
            }
               
               
         } catch (SQLException e) {
            e.printStackTrace();
         } finally {
            close();
         }
         return list2;
         
      }
      
      public ArrayList<TvpDTO> TvP1() {
         conn();
         
         ArrayList<TvpDTO> list2 = new ArrayList<TvpDTO>();
         try {
            String sql = "select r.mat_id,m.mat_name,m.mat_pro_name,m.mat_pro_count,m.mat_addr,round(avg(r.rev_score),1) as rev_avg from review r, mat m "
                  + "where m.mat_id = r.mat_id "
                  + "AND m.mat_pro_name = '����̽�ȸ' "
                  + "group by r.mat_id, m.mat_name, m.mat_pro_count, m.mat_pro_name, m.mat_addr "
                  + "order by m.mat_pro_count desc";
            psmt = conn.prepareStatement(sql);
            rs = psmt.executeQuery();
            
            while(rs.next()) {   
               String mat_id =  rs.getString(1);
               String mat_name =  rs.getString(2);
               String mat_pro_name = rs.getString(3);
               String mat_pro_count =  rs.getString(4);
               String mat_addr = rs.getString(5);
               Float rev_avg = rs.getFloat(6);
               
               dto = new TvpDTO(mat_id, mat_name, mat_pro_name, mat_pro_count, mat_addr, rev_avg);
               
               list2.add(dto);
               
            }
            
            
         } catch (SQLException e) {
            e.printStackTrace();
         } finally {
            close();
         }
         return list2;
         
      }
      public ArrayList<TvpDTO> TvP2() {
         conn();
         
         ArrayList<TvpDTO> list2 = new ArrayList<TvpDTO>();
         try {
            String sql = "select r.mat_id,m.mat_name,m.mat_pro_name,m.mat_pro_count,m.mat_addr,round(avg(r.rev_score),1) as rev_avg from review r, mat m "
                  + "where m.mat_id = r.mat_id "
                  + "AND m.mat_pro_name = '�������ǰ��Ĵ�' "
                  + "group by r.mat_id, m.mat_name, m.mat_pro_count, m.mat_pro_name, m.mat_addr "
                  + "order by m.mat_pro_count desc";
            psmt = conn.prepareStatement(sql);
            rs = psmt.executeQuery();
            
            while(rs.next()) {   
               String mat_id =  rs.getString(1);
               String mat_name =  rs.getString(2);
               String mat_pro_name = rs.getString(3);
               String mat_pro_count =  rs.getString(4);
               String mat_addr = rs.getString(5);
               Float rev_avg = rs.getFloat(6);
               
               dto = new TvpDTO(mat_id, mat_name, mat_pro_name, mat_pro_count, mat_addr, rev_avg);
               
               list2.add(dto);
               
            }
            
            
         } catch (SQLException e) {
            e.printStackTrace();
         } finally {
            close();
         }
         return list2;
         
      }
      
}