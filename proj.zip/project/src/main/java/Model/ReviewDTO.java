package Model;

public class ReviewDTO {

	
	private int rev_num;
	private String guest_id;
	private String mat_id;
	private String rev_contents;
	private int rev_score;
	private String rev_date;
	private String rev_filename;
	
	
	public ReviewDTO(int rev_num, String guest_id, String mat_id, String rev_contents, int rev_score, String rev_date,
			String rev_filename) {
		super();
		this.rev_num = rev_num;
		this.guest_id = guest_id;
		this.mat_id = mat_id;
		this.rev_contents = rev_contents;
		this.rev_score = rev_score;
		this.rev_date = rev_date;
		this.rev_filename = rev_filename;
	}
	
	public ReviewDTO(String guest_id, String mat_id, String rev_contents, int rev_score) {
		super();
		this.guest_id = guest_id;
		this.mat_id = mat_id;
		this.rev_contents = rev_contents;
		this.rev_score = rev_score;
	}

	public int getRev_num() {
		return rev_num;
	}

	public void setRev_num(int rev_num) {
		this.rev_num = rev_num;
	}

	public String getGuest_id() {
		return guest_id;
	}

	public void setGuest_id(String guest_id) {
		this.guest_id = guest_id;
	}

	public String getMat_id() {
		return mat_id;
	}

	public void setMat_id(String mat_id) {
		this.mat_id = mat_id;
	}

	public String getRev_contents() {
		return rev_contents;
	}

	public void setRev_contents(String rev_contents) {
		this.rev_contents = rev_contents;
	}

	public int getRev_score() {
		return rev_score;
	}

	public void setRev_score(int rev_score) {
		this.rev_score = rev_score;
	}

	public String getRev_date() {
		return rev_date;
	}

	public void setRev_date(String rev_date) {
		this.rev_date = rev_date;
	}

	public String getRev_filename() {
		return rev_filename;
	}

	public void setRev_filename(String rev_filename) {
		this.rev_filename = rev_filename;
	}
	
	
	
	
	
	
	
}
