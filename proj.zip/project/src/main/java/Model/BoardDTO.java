package Model;

public class BoardDTO {

   private int board_num;
   private String guest_id;
   private String board_title;
   private String board_filename;
   private String board_contents;
   private String board_date;
   

   
   public BoardDTO(int board_num, String guest_id, String board_title, String board_filename, String board_contents,
         String board_date) {
      super();
      this.board_num = board_num;
      this.guest_id = guest_id;
      this.board_title = board_title;
      this.board_filename = board_filename;
      this.board_contents = board_contents;
      this.board_date = board_date;
   }
   
   public BoardDTO(String guest_id, String board_title, String board_contents) {
	      super();
	      this.guest_id = guest_id;
	      this.board_title = board_title;
	      this.board_contents = board_contents;
	   }
   
   public int getBoard_num() {
      return board_num;
   }
   public void setBoard_num(int board_num) {
      this.board_num = board_num;
   }
   public String getGuest_id() {
      return guest_id;
   }
   public void setGuest_id(String guest_id) {
      this.guest_id = guest_id;
   }
   public String getBoard_title() {
      return board_title;
   }
   public void setBoard_title(String board_title) {
      this.board_title = board_title;
   }
   public String getBoard_filename() {
      return board_filename;
   }
   public void setBoard_filename(String board_filename) {
      this.board_filename = board_filename;
   }
   public String getBoard_contents() {
      return board_contents;
   }
   public void setBoard_contents(String board_contents) {
      this.board_contents = board_contents;
   }
   public String getBoard_date() {
      return board_date;
   }
   public void setBoard_date(String board_date) {
      this.board_date = board_date;
   }
   
   
}