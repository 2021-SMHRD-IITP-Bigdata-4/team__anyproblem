package Model;

public class RegionDTO {

	private int reg_id;
	private String reg_big;
	private String reg_small;
	
	public RegionDTO(int reg_id, String reg_big, String reg_small) {
		super();
		this.reg_id = reg_id;
		this.reg_big = reg_big;
		this.reg_small = reg_small;
	}
	
	public RegionDTO(String reg_big, String reg_small) {
		super();
		this.reg_big = reg_big;
		this.reg_small = reg_small;
	}
	
	public RegionDTO(String reg_big) {
		super();
		this.reg_big = reg_big;
	}

	public int getReg_id() {
		return reg_id;
	}

	public void setReg_id(int reg_id) {
		this.reg_id = reg_id;
	}

	public String getReg_big() {
		return reg_big;
	}

	public void setReg_big(String reg_big) {
		this.reg_big = reg_big;
	}

	public String getReg_small() {
		return reg_small;
	}

	public void setReg_small(String reg_small) {
		this.reg_small = reg_small;
	}
	
}
