package Model;

public class ClientDTO {
	
		private String guest_id;
		private String pw;
		private String name;
		private String phone;
		public ClientDTO(String guest_id, String pw, String name, String phone) {
			this.guest_id = guest_id;
			this.pw = pw;
			this.name = name;
			this.phone = phone;
		}
		public ClientDTO(String guest_id, String pw) {
			this.guest_id = guest_id;
			this.pw = pw;

		
		}
		public String getGuest_id() {
			return guest_id;
		}
		public void setGuest_id(String guest_id) {
			this.guest_id = guest_id;
		}
		public String getPw() {
			return pw;
		}
		public void setPw(String pw) {
			this.pw = pw;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		
		

		
		
}
