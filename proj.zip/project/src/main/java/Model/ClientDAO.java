package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClientDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	ResultSet rs = null;
	ClientDTO logindto = null;
	

	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");// ojdbc6.jar ���� Ȯ���ϱ�

			String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String db_id = "campus_e4";
			String db_pw = "smhrd4";

			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int join(ClientDTO dto) {
		conn();
		try {

			String sql = "insert into guest values(?,?,?,?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getGuest_id());
			psmt.setString(2, dto.getPw());
			psmt.setString(3, dto.getName());
			psmt.setString(4, dto.getPhone());
			cnt = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}
	public ClientDTO login(ClientDTO dto) {
		conn();
		
		try {
			String sql = "select * from guest where guest_id =? and pw =?";
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1,dto.getGuest_id());
			psmt.setString(2,dto.getPw());
			rs = psmt.executeQuery();
			if(rs.next()) {
				String id = rs.getString(1);
				String pw = rs.getString(2);
				String name = rs.getString(3);
				String phone = rs.getString(4);
				
				logindto = new ClientDTO(id, pw, name, phone); 
				
			}
			
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return logindto;
	}
	
	public int update(ClientDTO dto) {
		conn();
		try {
			String sql = "update guest set pw = ?, tel = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getPw());
			psmt.setString(2, dto.getPhone());
			cnt = psmt.executeUpdate();	
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		return cnt;
		
	}

	
	
}
