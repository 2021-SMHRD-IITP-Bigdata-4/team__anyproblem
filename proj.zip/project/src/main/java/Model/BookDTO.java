package Model;

public class BookDTO {

	private String bmark_num;
	private String guest_id;
	private String mat_id;
	public BookDTO(String bmark_num, String guest_id, String mat_id) {
		super();
		this.bmark_num = bmark_num;
		this.guest_id = guest_id;
		this.mat_id = mat_id;
	}
	public String getBmark_num() {
		return bmark_num;
	}
	public void setBmark_num(String bmark_num) {
		this.bmark_num = bmark_num;
	}
	public String getGuest_id() {
		return guest_id;
	}
	public void setGuest_id(String guest_id) {
		this.guest_id = guest_id;
	}
	public String getMat_id() {
		return mat_id;
	}
	public void setMat_id(String mat_id) {
		this.mat_id = mat_id;
	}
	
	
}
