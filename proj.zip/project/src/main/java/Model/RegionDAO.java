package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RegionDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	ResultSet rs = null;
	RegionDTO dto = null;
	ArrayList<RegionDTO> list = null;
	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String db_id = "campus_e4";
			String db_pw = "smhrd4";

			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public RegionDTO findRegionID(String big_city, String small_city) {
		conn();
		String sql = "select * from region where reg_big = ? and reg_small = ?";
		
		try {
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, big_city);
			psmt.setString(2, small_city);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				int reg_id = rs.getInt(1);
				String reg_big =  rs.getString(2);
				String reg_small =  rs.getString(3);
				
				dto = new RegionDTO(reg_id, reg_big, reg_small);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		} 
		return dto;
	}
	
	public RegionDTO findRegionIDvv(String big_city) {
		conn();
		String sql = "select * from region where reg_big = ?";
		
		try {
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, big_city);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				int reg_id = rs.getInt(1);
				String reg_big =  rs.getString(2);
				String reg_small =  rs.getString(3);
				
				dto = new RegionDTO(reg_id, reg_big, reg_small);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		} 
		return dto;
	}
	
}
