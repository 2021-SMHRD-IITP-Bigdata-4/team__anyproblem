package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ReviewDAO {

	

	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	ReviewDTO top5 = null;
	ResultSet rs = null;
	ReviewDTO dto = null;
	ArrayList<ReviewDTO> list = null;
	ArrayList<ReviewDTO> relist = null;

	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");// ojdbc6.jar ���� Ȯ���ϱ�

			String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String db_id = "campus_e4";
			String db_pw = "smhrd4";

			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<ReviewDTO> revTop5() {
		conn();
		ArrayList<ReviewDTO> list = new ArrayList<ReviewDTO>();
		
		String sql = "select m.mat_name, r.mat_id, count(r.rev_contents) as rev_cnt from review r, mat m where r.mat_id = m.mat_id group by r.mat_id, m.mat_id, m.mat_name order by rev_cnt desc;";
		try {
			psmt = conn.prepareStatement(sql);
			rs= psmt.executeQuery();
			
			while(rs.next()) {
				String mat_name = rs.getString(1);				
				list.add(top5);
				
			}
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
		
	}
	
	public ArrayList<ReviewDTO> allre(String matid) {
		conn();
		relist = new ArrayList<ReviewDTO>();
		
		String sql = "select * from review where mat_id = ? order by rev_date desc";
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1,matid);
			rs= psmt.executeQuery();
			
			while(rs.next()) {
				int rev_num = rs.getInt(1);
				String guest_id = rs.getString(2);
				String mat_id = rs.getString(3);
				String content = rs.getString(4);	
				int rev_score = rs.getInt(5);
				String rev_date = rs.getString(6);
				String rev_file = rs.getString(7);
				
				dto = new ReviewDTO(rev_num, guest_id, mat_id, content, rev_score, rev_date, rev_file);
				
				relist.add(dto);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return relist;
		
	}
	
	public int insertReview(ReviewDTO dto) {
	      conn();
	      String sql = "insert into review values(501,?,?,?,?,sysdate,'img')";
	      
	      try {
	         psmt = conn.prepareStatement(sql);
	         
	         psmt.setString(1,dto.getGuest_id());
	         psmt.setString(2,dto.getMat_id());
	         psmt.setString(3,dto.getRev_contents());
	         psmt.setInt(4, dto.getRev_score());
	         cnt = psmt.executeUpdate();
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         close();
	      } 
	      return cnt;
	   }
	
	
}
