package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class BookDAO {
	Connection conn = null;
	   PreparedStatement psmt = null;
	   int cnt = 0;
	   ResultSet rs = null;
	   BookDTO dto = null;
	   ArrayList<BookDTO> list = null;
	   
	    public void conn() {
	         try {
	            Class.forName("oracle.jdbc.driver.OracleDriver");

	            String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
	            String db_id = "campus_e4";
	            String db_pw = "smhrd4";

	            conn = DriverManager.getConnection(db_url, db_id, db_pw);

	         } catch (Exception e) {
	            e.printStackTrace();
	         }

	      }
	      
	      public void close() {
	         try {
	            if (rs != null) {
	               rs.close();
	            }
	            if (psmt != null) {
	               psmt.close();
	            }
	            if (conn != null) {
	               conn.close();
	            }

	         } catch (SQLException e) {
	            e.printStackTrace();
	         }
	      }

	   public int book(String gid, String mid) {
	      conn();
	      String sql = "insert into book values(1,?,?)";
	      
	      try {
	         psmt = conn.prepareStatement(sql);
	         
	         psmt.setString(1,gid);
	         psmt.setString(2,mid);
	         cnt = psmt.executeUpdate();
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         close();
	      } 
	      return cnt;
	   }
}
