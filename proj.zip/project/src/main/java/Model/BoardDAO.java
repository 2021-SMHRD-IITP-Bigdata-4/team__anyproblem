package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class BoardDAO {
   
   Connection conn = null;
   PreparedStatement psmt = null;
   int cnt = 0;
   ResultSet rs = null;
   BoardDTO dto = null;
   ArrayList<BoardDTO> list = null;
   
    public void conn() {
         try {
            Class.forName("oracle.jdbc.driver.OracleDriver");

            String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
            String db_id = "campus_e4";
            String db_pw = "smhrd4";

            conn = DriverManager.getConnection(db_url, db_id, db_pw);

         } catch (Exception e) {
            e.printStackTrace();
         }

      }
      
      public void close() {
         try {
            if (rs != null) {
               rs.close();
            }
            if (psmt != null) {
               psmt.close();
            }
            if (conn != null) {
               conn.close();
            }

         } catch (SQLException e) {
            e.printStackTrace();
         }
      }

   public int insertBoard(BoardDTO dto) {
      conn();
      String sql = "insert into board values(board_num.nextval,?,?,'img',?,sysdate)";
      
      try {
         psmt = conn.prepareStatement(sql);
         
         psmt.setString(1,dto.getGuest_id());
         psmt.setString(2,dto.getBoard_title());
         psmt.setString(3,dto.getBoard_contents());
         cnt = psmt.executeUpdate();
         
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
         close();
      } 
      return cnt;
   }
   
   public ArrayList<BoardDTO> SelectAll () {
      
      
      String sql = "select * from board";
      ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();
      
      try {
         conn();
         psmt = conn.prepareStatement(sql);
         rs = psmt.executeQuery();
         
         while (rs.next()) {
            int board_num = rs.getInt(1);
            System.out.println("Ȯ�� : " + board_num);
            String guest_id = rs.getString(2);
            String board_title = rs.getString(3);
            String board_filename = rs.getString(4);
            String board_contents = rs.getString(5);
            String board_date = rs.getString(6);
            dto = new BoardDTO(board_num, guest_id, board_title, board_filename, board_contents, board_date);
            list.add(dto);
            
         }
         
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
         close();
      }
      return list;
   }
   
   public BoardDTO selectOne (String num) {
      conn();
      
      String sql = "select * from board where num = ?";
      try {
         psmt = conn.prepareStatement(sql);
         psmt.setString(1, num);
         rs = psmt.executeQuery();
         
         if(rs.next()) {
            int num1 = rs.getInt(1);
            String title =  rs.getString(2);
            String writer =  rs.getString(3);
            String fileName =  rs.getString(4);
            String content =  rs.getString(5);
            String day =  rs.getString(6);
            
            dto = new BoardDTO(num1, title, writer, fileName, content, day);
         }
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
         close();
      }
      return dto;
   }
   
   
   
   
}