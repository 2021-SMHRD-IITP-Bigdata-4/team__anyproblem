package Model;


public class TvpDTO {

   private String mat_id;
   private String mat_name;
   private String mat_pro_name;
   private String mat_pro_count;
   private String mat_addr;
   private float rev_avg;

   public TvpDTO(String mat_id, String mat_name, String mat_pro_name, String mat_pro_count, String mat_addr,
         float rev_avg) {
      super();
      this.mat_id = mat_id;
      this.mat_name = mat_name;
      this.mat_pro_name = mat_pro_name;
      this.mat_pro_count = mat_pro_count;
      this.mat_addr = mat_addr;
      this.rev_avg = rev_avg;
   }

   public String getMat_id() {
      return mat_id;
   }

   public void setMat_id(String mat_id) {
      this.mat_id = mat_id;
   }

   public String getMat_name() {
      return mat_name;
   }

   public void setMat_name(String mat_name) {
      this.mat_name = mat_name;
   }

   public String getMat_pro_name() {
      return mat_pro_name;
   }

   public void setMat_pro_name(String mat_pro_name) {
      this.mat_pro_name = mat_pro_name;
   }

   public String getMat_pro_count() {
      return mat_pro_count;
   }

   public void setMat_pro_count(String mat_pro_count) {
      this.mat_pro_count = mat_pro_count;
   }

   public String getMat_addr() {
      return mat_addr;
   }

   public void setMat_addr(String mat_addr) {
      this.mat_addr = mat_addr;
   }

   public float getRev_avg() {
      return rev_avg;
   }

   public void setRev_avg(float rev_avg) {
      this.rev_avg = rev_avg;
   }

}